\
package com.example.negativescanner

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var btnFreeze: Button
    private lateinit var btnSave: Button
    private lateinit var switchAutoWb: Switch

    private var imageCapture: ImageCapture? = null
    private var analyzer: ImageAnalysis? = null
    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    // State
    private var frozenBitmap: Bitmap? = null
    private var autoWbEnabled: Boolean = true

    private val permissions = mutableListOf(Manifest.permission.CAMERA).apply {
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.READ_MEDIA_IMAGES)
    }.toTypedArray()

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val granted = result.all { it.value }
        if (granted) startCamera()
        else Toast.makeText(this, "Kamera-Erlaubnis benötigt", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        btnFreeze = findViewById(R.id.btnFreeze)
        btnSave = findViewById(R.id.btnSave)
        switchAutoWb = findViewById(R.id.switchAutoWb)

        switchAutoWb.setOnCheckedChangeListener { _, isChecked ->
            autoWbEnabled = isChecked
        }

        btnFreeze.setOnClickListener {
            // Toggle freeze: if not frozen, take snapshot from latest analyzed frame
            frozenBitmap?.let {
                // Unfreeze
                frozenBitmap = null
                btnSave.isEnabled = false
            } ?: run {
                // Take snapshot from the previewView (not perfect, but works as quick capture)
                previewView.bitmap?.let { bmp ->
                    frozenBitmap = bmp.copy(Bitmap.Config.ARGB_8888, true)
                    btnSave.isEnabled = true
                } ?: Toast.makeText(this, "Kein Frame verfügbar", Toast.LENGTH_SHORT).show()
            }
        }

        btnSave.setOnClickListener {
            val bmp = frozenBitmap ?: previewView.bitmap
            if (bmp == null) {
                Toast.makeText(this, "Nichts zu speichern", Toast.LENGTH_SHORT).show()
            } else {
                saveBitmap(bmp)
            }
        }

        if (permissions.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startCamera()
        } else {
            requestPermissionsLauncher.launch(permissions)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            analyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { analysis ->
                    analysis.setAnalyzer(cameraExecutor) { image ->
                        // Convert to ARGB bitmap, invert, apply optional AWB, show in PreviewView via overlay? 
                        // Simpler approach: use PreviewView output and rely on freeze/save for output.
                        image.close()
                    }
                }

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture, analyzer
                )
            } catch (exc: Exception) {
                Toast.makeText(this, "Kamera-Initialisierung fehlgeschlagen: ${exc.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val name = "negscan_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NegativeScanner")
        }
        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri != null) {
            resolver.openOutputStream(uri).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            Toast.makeText(this, "Gespeichert: $name", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Speichern fehlgeschlagen", Toast.LENGTH_SHORT).show()
        }
    }

    // Example CPU invert function (unused in current simplified pipeline)
    private fun invertBitmap(src: Bitmap, autoWb: Boolean): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(w * h)
        src.getPixels(pixels, 0, w, 0, 0, w, h)

        var rSum = 0L; var gSum = 0L; var bSum = 0L
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = 255 - ((p shr 16) and 0xFF)
            val g = 255 - ((p shr 8) and 0xFF)
            val b = 255 - (p and 0xFF)
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            rSum += r; gSum += g; bSum += b
        }

        if (autoWb) {
            val n = max(1, pixels.size)
            val rMean = (rSum / n).toInt()
            val gMean = (gSum / n).toInt()
            val bMean = (bSum / n).toInt()
            // Simple gray world: scale channels so mean becomes mid-gray 128
            val rGain = 128f / max(1, rMean)
            val gGain = 128f / max(1, gMean)
            val bGain = 128f / max(1, bMean)
            for (i in pixels.indices) {
                val p = pixels[i]
                val r = min(255, (rGain * ((p shr 16) and 0xFF)).toInt())
                val g = min(255, (gGain * ((p shr 8) and 0xFF)).toInt())
                val b = min(255, (bGain * (p and 0xFF)).toInt())
                pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }
}
