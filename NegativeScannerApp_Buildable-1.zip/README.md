# NegativeScannerApp – Build-Anleitung

Dies ist ein **build-fertiges Android-Studio-Projekt (Kotlin + CameraX)**, das eine Live-Vorschau zeigt,
Frames invertieren kann (als Negativ→Positiv) und eingefrorene Bilder als JPG nach `Pictures/NegativeScanner` speichert.

## Schnellstart (Android Studio)
1. Android Studio (Giraffe/Iguana oder neuer) + **JDK 17** installieren.
2. Projekt öffnen (`File > Open`), die **Android 14 / compileSdk=34**-Pakete installieren lassen.
3. Run-Button drücken – App startet im Gerät/Emulator.
4. **APK**: `Build > Build APK(s)` → Debug-APK wird erzeugt.

## CLI (Gradle)
> Erfordert eine Gradle-Wrapper-Erzeugung, da der Wrapper nicht im Repo liegt.

```bash
# im Projektordner
gradle wrapper --gradle-version 8.6
./gradlew assembleDebug
# APK unter app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions (optional)
Lege diese Datei unter `.github/workflows/android.yml` an, um bei jedem Push eine Debug-APK zu builden (ohne Wrapper – wir installieren Gradle 8.6):

```yaml
name: Android CI

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Install Gradle 8.6
        run: |
          curl -s https://get.sdkman.io | bash
          source "$HOME/.sdkman/bin/sdkman-init.sh"
          sdk install gradle 8.6
          echo "GRADLE_HOME=$(sdk home gradle 8.6)" >> $GITHUB_ENV
          echo "$GRADLE_HOME/bin" >> $GITHUB_PATH
      - name: Build debug APK
        run: gradle assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-debug
          path: app/build/outputs/apk/debug/app-debug.apk
```

## Signieren (Release)
- In Android Studio: `Build > Generate Signed Bundle / APK` und einen Keystore anlegen.
- `release`-BuildType ist vorbereitet (ProGuard aktiv).

Viel Erfolg! ✨
